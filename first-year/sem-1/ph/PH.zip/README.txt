PH - Physics

Lab6 is only for those who need to recover a lab
At least online, the teacher asks questions, you'll be rewarded with bonus points to the exam/seminar/lab grades