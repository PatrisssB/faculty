AG - Algebra and Geometry

Some lectures are missing because she used the same pdf for 2 lectures